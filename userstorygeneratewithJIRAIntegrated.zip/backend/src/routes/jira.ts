import express from 'express'
import fetch from 'node-fetch'

export const jiraRouter = express.Router()

type JiraConfig = {
  baseUrl: string
  email: string
  apiToken: string
}

let jiraConfig: JiraConfig | null = null

const makeAuthHeader = (email: string, token: string) => {
  const b = Buffer.from(`${email}:${token}`).toString('base64')
  return `Basic ${b}`
}

jiraRouter.post('/connect', async (req: express.Request, res: express.Response) => {
  try {
    const { baseUrl, email, apiToken } = req.body
    if (!baseUrl || !email || !apiToken) {
      res.status(400).json({ error: 'baseUrl, email and apiToken are required' })
      return
    }

    // Test connection by calling /rest/api/3/myself
    const url = `${baseUrl.replace(/\/$/, '')}/rest/api/3/myself`
    const resp = await fetch(url, {
      headers: {
        Authorization: makeAuthHeader(email, apiToken),
        Accept: 'application/json'
      }
    })

    if (!resp.ok) {
      const text = await resp.text().catch(() => '')
      res.status(502).json({ error: `Failed to connect to Jira: ${resp.status} ${text}` })
      return
    }

    jiraConfig = { baseUrl: baseUrl.replace(/\/$/, ''), email, apiToken }
    res.json({ ok: true })
  } catch (error: any) {
    console.error('Error in /api/jira/connect', error)
    res.status(500).json({ error: error?.message || 'Internal error' })
  }
})

jiraRouter.get('/projects', async (req: express.Request, res: express.Response) => {
  try {
    if (!jiraConfig) {
      res.status(400).json({ error: 'Not connected to Jira' })
      return
    }

    const headers = {
      Authorization: makeAuthHeader(jiraConfig.email, jiraConfig.apiToken),
      Accept: 'application/json'
    }

    // Fetch all projects
    const url = `${jiraConfig.baseUrl}/rest/api/3/project`
    console.log('Fetching Jira projects from:', url)
    const resp = await fetch(url, { method: 'GET', headers })

    if (!resp.ok) {
      const text = await resp.text().catch(() => '')
      console.error('Failed to fetch projects, status:', resp.status, 'body:', text)
      res.status(502).json({ error: `Failed to fetch projects: ${resp.status} ${text}` })
      return
    }

    const projects = (await resp.json()) as any[]
    console.log('Available projects:', projects.map((p: any) => ({ key: p.key, name: p.name })))
    
    res.json({
      projects: projects.map((p: any) => ({
        key: p.key,
        name: p.name,
        id: p.id
      }))
    })
  } catch (error: any) {
    console.error('Error in /api/jira/projects', error)
    res.status(500).json({ error: error?.message || 'Internal error' })
  }
})

jiraRouter.get('/stories', async (req: express.Request, res: express.Response) => {
  try {
    if (!jiraConfig) {
      res.status(400).json({ error: 'Not connected to Jira' })
      return
    }

    const { project } = req.query
    if (!project) {
      res.status(400).json({ error: 'Missing project query parameter' })
      return
    }

    console.log('Fetching stories for project:', project)

    const headers = {
      Authorization: makeAuthHeader(jiraConfig.email, jiraConfig.apiToken),
      Accept: 'application/json',
      'Content-Type': 'application/json',
      'Cache-Control': 'no-cache, no-store, must-revalidate, max-age=0',
      'Pragma': 'no-cache',
      'Expires': '0'
    }

    // Try multiple JQL formats since Jira can be finicky
    // Note: Project keys should NOT be quoted; project names should be quoted
    const jqlVariants = [
      `project = ${project} ORDER BY created DESC`,
      `project = ${project} AND type in (Story, Task) ORDER BY created DESC`,
      `project = "${project}" ORDER BY created DESC`,
      `project = ${project} AND status != Done ORDER BY created DESC`,
      `project = ${project} AND type = Story ORDER BY created DESC`
    ]

    let resp: any = null
    let lastError = ''
    let successJql = ''

    for (const jql of jqlVariants) {
      console.log('Trying JQL:', jql)
      // Add cache-buster timestamp to prevent 304 responses
      const cacheBuster = `&_t=${Date.now()}&_r=${Math.random()}`
      const searchGetUrl = `${jiraConfig.baseUrl}/rest/api/3/search?jql=${encodeURIComponent(jql)}&startAt=0&maxResults=50&fields=key,summary${cacheBuster}`
      console.log('GET request to:', searchGetUrl)
      
      try {
        resp = await fetch(searchGetUrl, { method: 'GET', headers })
        console.log('Response status:', resp.status, 'ok:', resp.ok)
        
        // 304 Not Modified means cached - treat as failure and try next variant
        if (resp.status === 304) {
          console.warn('✗ Got 304 Not Modified (cached), trying next variant')
          resp = null
          continue
        }
        if (resp.ok) {
          successJql = jql
          console.log('✓ JQL succeeded with:', jql)
          break
        } else {
          const txt = await resp.text().catch(() => '')
          lastError = txt
          console.warn('✗ JQL failed:', resp.status, txt)
        }
      } catch (err: any) {
        console.error('✗ JQL error:', err.message)
        lastError = err.message
      }
    }

    // 2) If GET failed, try the newer POST /rest/api/3/search/jql endpoint with two possible payload shapes
    if (!resp?.ok) {
      const txt = await resp?.text().catch(() => '')
      console.warn('Jira GET /search failed, status=', resp?.status, 'response:', txt)

      const searchJqlUrl = `${jiraConfig.baseUrl}/rest/api/3/search/jql`

      // Try several payload shapes for /search/jql (capture responses for debugging)
      const attempts: Array<{ name: string; body: any }> = [
        // Try with fields parameter in the request
        { name: 'with_fields', body: { jql: successJql || jqlVariants[0], startAt: 0, maxResults: 50, fields: ['key', 'summary'] } },
        // Minimal shapes first (some Jira instances require minimal payload)
        { name: 'min_jql_only', body: { jql: successJql || jqlVariants[0] } },
        { name: 'min_query_only', body: { query: successJql || jqlVariants[0] } },
        { name: 'payloadA', body: { query: successJql || jqlVariants[0], startAt: 0, maxResults: 50, fields: ['summary'] } },
        { name: 'payloadB', body: { jql: successJql || jqlVariants[0], startAt: 0, maxResults: 50, fields: ['summary'] } },
        { name: 'payloadC', body: { query: { jql: successJql || jqlVariants[0], startAt: 0, maxResults: 50 }, fields: ['summary'] } },
        { name: 'payloadD', body: { query: { query: successJql || jqlVariants[0] }, startAt: 0, maxResults: 50, fields: ['summary'] } },
        { name: 'payloadE', body: { query: { jql: successJql || jqlVariants[0], startAt: 0, maxResults: 50 }, fields: ['summary'] } },
        { name: 'payloadF', body: { query: { jql: successJql || jqlVariants[0] } } }
      ]

      let success = false
      for (const attempt of attempts) {
        try {
          console.warn('Trying /search/jql with', attempt.name)
          const bodyStr = JSON.stringify(attempt.body)
          resp = await fetch(searchJqlUrl, { method: 'POST', headers, body: bodyStr })
          if (resp.ok) {
            success = true
            console.log('✓ /search/jql succeeded with:', attempt.name)
            break
          }
          const txt = await resp.text().catch(() => '')
          console.warn(`Jira /search/jql ${attempt.name} failed`, resp.status, txt)
        } catch (err: any) {
          console.error('Error while trying /search/jql', attempt.name, err?.message || err)
        }
      }

      if (!success) {
        // Final fallback: older /rest/api/3/search POST (some instances still accept it)
        const fallbackUrl = `${jiraConfig.baseUrl}/rest/api/3/search`
        const fallbackBody = { jql: successJql || jqlVariants[0], startAt: 0, maxResults: 50, fields: ['summary'] }
        resp = await fetch(fallbackUrl, { method: 'POST', headers, body: JSON.stringify(fallbackBody) })
        if (!resp.ok) {
          const txt2 = await resp.text().catch(() => '')
          console.error('Jira /search fallback failed', resp.status, txt2)
          res.status(502).json({ error: `Failed to fetch stories: ${resp.status} ${txt2}` })
          return
        }
      }
    }

    if (!resp.ok) {
      const text = await resp.text().catch(() => '')
      console.error('Failed to fetch stories, status:', resp.status, 'body:', text)
      res.status(502).json({ error: `Failed to fetch stories: ${resp.status} ${text}` })
      return
    }

    const data = await resp.json()
    console.log('Jira API response:', JSON.stringify(data, null, 2))

    let rawIssues = data.issues || []
    console.log('Number of issues found:', rawIssues.length)
    console.log('Raw issues:', JSON.stringify(rawIssues.slice(0, 2), null, 2))
    
    if (rawIssues.length === 0 && data.errorMessages) {
      console.error('Jira returned error:', data.errorMessages)
      res.status(400).json({ error: `Jira error: ${data.errorMessages.join(', ')}` })
      return
    }

    // If issues only have 'id' field (from /search/jql), fetch full details
    const firstIssue = rawIssues.length > 0 ? rawIssues[0] : null
    const issuesHaveOnlyId = firstIssue && firstIssue.id && !firstIssue.key && !firstIssue.fields
    
    if (issuesHaveOnlyId) {
      console.log('Issues have only ID, fetching full details for', rawIssues.length, 'issues...')
      try {
        // Fallback: fetch each issue individually using /rest/api/3/issue/{id}
        const detailedIssues = []
        for (const issue of rawIssues) {
          try {
            const issueUrl = `${jiraConfig.baseUrl}/rest/api/3/issue/${issue.id}?fields=key,summary`
            console.log('Fetching issue details from:', issueUrl)
            const issueResp = await fetch(issueUrl, { headers })
            if (issueResp.ok) {
              const issueData = (await issueResp.json()) as any
              console.log('Got issue response:', JSON.stringify(issueData, null, 2))
              // JIRA returns key at top level, summary in fields
              if (issueData.key) {
                detailedIssues.push(issueData)
                console.log('Added issue:', issueData.key, issueData.fields?.summary)
              }
            } else {
              console.warn('Failed to fetch issue', issue.id, issueResp.status)
              const errText = await issueResp.text().catch(() => '')
              console.warn('Error response:', errText)
            }
          } catch (err) {
            console.error('Error fetching issue', issue.id, err)
          }
        }
        rawIssues = detailedIssues
        console.log('Fetched', rawIssues.length, 'issues with full details')
      } catch (err: any) {
        console.error('Error fetching issue details', err?.message || err)
      }
    }

    const issues = rawIssues.map((i: any) => {
      // Handle different response formats
      const id = i.key || i.id  // i.key from /rest/api/3/issue/{id}, i.id from search
      const title = i.fields?.summary || i.summary || 'Untitled'
      console.log('Mapping issue to:', { id, title })
      return { id, title }
    })
    console.log('Final issues response:', issues)
    res.json({ issues })
  } catch (error: any) {
    console.error('Error in /api/jira/stories', error)
    res.status(500).json({ error: error?.message || 'Internal error' })
  }
})

const renderDescription = (desc: any): string => {
  if (!desc) return ''
  if (typeof desc === 'string') return desc
  // Try to walk Atlassian document format
  const texts: string[] = []
  const walk = (node: any) => {
    if (!node) return
    if (typeof node === 'string') {
      texts.push(node)
      return
    }
    if (Array.isArray(node)) {
      node.forEach(walk)
      return
    }
    if (node.type === 'text' && typeof node.text === 'string') {
      texts.push(node.text)
    }
    if (node.content) walk(node.content)
  }
  walk(desc)
  return texts.join('\n')
}

jiraRouter.get('/story/:key', async (req: express.Request, res: express.Response) => {
  try {
    if (!jiraConfig) {
      res.status(400).json({ error: 'Not connected to Jira' })
      return
    }
    const { key } = req.params
    const url = `${jiraConfig.baseUrl}/rest/api/3/issue/${encodeURIComponent(key)}?fields=summary,description`
    const resp = await fetch(url, {
      headers: {
        Authorization: makeAuthHeader(jiraConfig.email, jiraConfig.apiToken),
        Accept: 'application/json'
      }
    })

    if (!resp.ok) {
      const text = await resp.text().catch(() => '')
      res.status(502).json({ error: `Failed to fetch story: ${resp.status} ${text}` })
      return
    }

    const data = (await resp.json()) as any
    const title = data.fields?.summary || ''
    const rawDesc = data.fields?.description
    const description = renderDescription(rawDesc)
    // Try to extract acceptance criteria heuristically
    let acceptanceCriteria = ''
    if (description) {
      const match = description.match(/Acceptance Criteria[:\-\s]*([\s\S]*)/i)
      if (match) acceptanceCriteria = match[1].trim()
    }

    res.json({ key, title, description, acceptanceCriteria })
  } catch (error: any) {
    console.error('Error in /api/jira/story/:key', error)
    res.status(500).json({ error: error?.message || 'Internal error' })
  }
})

export default jiraRouter
