import { useState } from 'react'
import { generateTests, connectJira, fetchJiraStories, fetchJiraStory, fetchJiraProjects } from './api'
import { GenerateRequest, GenerateResponse, TestCase } from './types'
import * as XLSX from 'xlsx'
import jsPDF from 'jspdf'
import 'jspdf-autotable'

function App() {
  const [formData, setFormData] = useState<GenerateRequest>({
    storyTitle: '',
    acceptanceCriteria: '',
    description: '',
    additionalInfo: ''
  })
  const [results, setResults] = useState<GenerateResponse | null>(null)
  const [isLoading, setIsLoading] = useState<boolean>(false)
  const [error, setError] = useState<string | null>(null)
  const [expandedTestCases, setExpandedTestCases] = useState<Set<string>>(new Set())
  const [jiraConnected, setJiraConnected] = useState<boolean>(false)
  const [showJiraForm, setShowJiraForm] = useState<boolean>(false)
  const [jiraBaseUrl, setJiraBaseUrl] = useState<string>('https://umamahechn.atlassian.net/')
  const [jiraEmail, setJiraEmail] = useState<string>('umamahe.chn@gmail.com')
  const [jiraToken, setJiraToken] = useState<string>('ATATT3xFfGF0ik6Oe_cRaGbrAwtsv2lM8fqXoA575MDoucgPVxkXuEIlS-zgNUOPa4C8VAO_EystKMOdNwtAvbQJ5Q0aogmUJmq_f6zzXBLCJjRQuWW5GQluBHVI2g6vkKVvT0IM5pbFDoLXxa9m1hMexjHmlMorGeExRI6ftNZyjcYlOPGwxxE=E2C42F76')
  const [jiraLoading, setJiraLoading] = useState<boolean>(false)
  const [jiraError, setJiraError] = useState<string | null>(null)
  const [stories, setStories] = useState<Array<{ id: string; title: string }>>([])
  const [selectedStory, setSelectedStory] = useState<string>('')
  const [jiraProject, setJiraProject] = useState<string>('Agentic AI')
  const [jiraProjects, setJiraProjects] = useState<Array<{ key: string; name: string; id: string }>>([])
  const [projectsLoading, setProjectsLoading] = useState<boolean>(false)

  const toggleTestCaseExpansion = (testCaseId: string) => {
    const newExpanded = new Set(expandedTestCases)
    if (newExpanded.has(testCaseId)) {
      newExpanded.delete(testCaseId)
    } else {
      newExpanded.add(testCaseId)
    }
    setExpandedTestCases(newExpanded)
  }

  const buildRows = (cases: TestCase[]) => {
    return cases.map(tc => ({
      'Test Case ID': tc.id,
      Title: tc.title,
      Category: tc.category,
      'Expected Result': tc.expectedResult,
      'Test Data': (tc as any).testData || '',
      Steps: tc.steps ? tc.steps.join('\n') : ''
    }))
  }

  const downloadCSV = (cases: TestCase[]) => {
    if (!cases || cases.length === 0) return
    const rows = buildRows(cases)
    const headers = Object.keys(rows[0])
    const csv = [
      headers.join(','),
      ...rows.map(r => headers.map(h => `"${String((r as any)[h] || '').replace(/"/g, '""')}"`).join(','))
    ].join('\n')

    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'test-cases.csv'
    a.click()
    URL.revokeObjectURL(url)
  }

  const downloadXLSX = (cases: TestCase[]) => {
    if (!cases || cases.length === 0) return
    const rows = buildRows(cases)
    const ws = XLSX.utils.json_to_sheet(rows)
    const wb = XLSX.utils.book_new()
    XLSX.utils.book_append_sheet(wb, ws, 'TestCases')
    const wbout = XLSX.write(wb, { bookType: 'xlsx', type: 'array' })
    const blob = new Blob([wbout], { type: 'application/octet-stream' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = 'test-cases.xlsx'
    a.click()
    URL.revokeObjectURL(url)
  }

  const downloadPDF = (cases: TestCase[]) => {
    if (!cases || cases.length === 0) return
    const doc = new jsPDF('landscape', 'pt', 'letter')
    const head = [['Test Case ID', 'Title', 'Category', 'Expected Result', 'Test Data', 'Steps']]
    const body = cases.map(tc => [
      tc.id,
      tc.title,
      tc.category,
      tc.expectedResult,
      (tc as any).testData || '',
      tc.steps ? tc.steps.join('\n') : ''
    ])
    ;(doc as any).autoTable({
      head,
      body,
      styles: { fontSize: 9 },
      headStyles: { fillColor: [44, 62, 80] },
      startY: 20,
      theme: 'striped',
      margin: { left: 20, right: 20 }
    })
    doc.save('test-cases.pdf')
  }

  const handleInputChange = (field: keyof GenerateRequest, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    
    if (!formData.storyTitle.trim() || !formData.acceptanceCriteria.trim()) {
      setError('Story Title and Acceptance Criteria are required')
      return
    }

    setIsLoading(true)
    setError(null)
    
    try {
      const response = await generateTests(formData)
      setResults(response)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate tests')
    } finally {
      setIsLoading(false)
    }
  }

  const handleConnectJira = async () => {
    setJiraLoading(true)
    setJiraError(null)
    try {
      await connectJira(jiraBaseUrl, jiraEmail, jiraToken)
      setJiraConnected(true)
      // load available projects
      setProjectsLoading(true)
      try {
        const projectsData = await fetchJiraProjects()
        setJiraProjects(projectsData.projects || [])
        // Set first project as default
        if (projectsData.projects && projectsData.projects.length > 0) {
          setJiraProject(projectsData.projects[0].key)
          // load stories for first project
          const data = await fetchJiraStories(projectsData.projects[0].key)
          setStories(data.issues || [])
        }
      } catch (err: any) {
        console.error('Error fetching projects:', err)
        setJiraError(`Connected but failed to load projects: ${err.message}`)
      } finally {
        setProjectsLoading(false)
      }
    } catch (err: any) {
      setJiraError(err instanceof Error ? err.message : String(err))
      setJiraConnected(false)
    } finally {
      setJiraLoading(false)
    }
  }

  const handleLoadStories = async () => {
    setJiraLoading(true)
    setJiraError(null)
    try {
      const data = await fetchJiraStories(jiraProject)
      setStories(data.issues || [])
    } catch (err: any) {
      setJiraError(err instanceof Error ? err.message : String(err))
    } finally {
      setJiraLoading(false)
    }
  }

  const handleLoadStoriesForProject = async (projectKey: string) => {
    setJiraLoading(true)
    setJiraError(null)
    try {
      const data = await fetchJiraStories(projectKey)
      setStories(data.issues || [])
    } catch (err: any) {
      setJiraError(err instanceof Error ? err.message : String(err))
    } finally {
      setJiraLoading(false)
    }
  }

  const handleLinkStory = async () => {
    if (!selectedStory) return
    setJiraLoading(true)
    setJiraError(null)
    try {
      const data = await fetchJiraStory(selectedStory)
      // populate form with story details
      setFormData(prev => ({
        ...prev,
        storyTitle: data.title || prev.storyTitle,
        description: data.description || prev.description,
        acceptanceCriteria: data.acceptanceCriteria || prev.acceptanceCriteria
      }))
    } catch (err: any) {
      setJiraError(err instanceof Error ? err.message : String(err))
    } finally {
      setJiraLoading(false)
    }
  }

  return (
    <div>
      <style>{`
        * {
          box-sizing: border-box;
          margin: 0;
          padding: 0;
        }
        
        body {
          font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', sans-serif;
          background-color: #f5f5f5;
          color: #333;
          line-height: 1.6;
        }
        
        .container {
          max-width: 95%;
          width: 100%;
          margin: 0 auto;
          padding: 20px;
          min-height: 100vh;
        }
        
        @media (min-width: 768px) {
          .container {
            max-width: 90%;
            padding: 30px;
          }
        }
        
        @media (min-width: 1024px) {
          .container {
            max-width: 85%;
            padding: 40px;
          }
        }
        
        @media (min-width: 1440px) {
          .container {
            max-width: 1800px;
            padding: 50px;
          }
        }
        
        .header {
          text-align: center;
          margin-bottom: 40px;
        }
        
        .title {
          font-size: 2.5rem;
          color: #2c3e50;
          margin-bottom: 10px;
        }
        
        .subtitle {
          color: #666;
          font-size: 1.1rem;
        }
        
        .form-container {
          background: white;
          border-radius: 8px;
          padding: 30px;
          box-shadow: 0 2px 10px rgba(0,0,0,0.1);
          margin-bottom: 30px;
        }
        
        .form-group {
          margin-bottom: 20px;
        }
        
        .form-label {
          display: block;
          font-weight: 600;
          margin-bottom: 8px;
          color: #2c3e50;
        }
        
        .form-input, .form-textarea {
          width: 100%;
          padding: 12px;
          border: 2px solid #e1e8ed;
          border-radius: 6px;
          font-size: 14px;
          transition: border-color 0.2s;
        }
        
        .form-input:focus, .form-textarea:focus {
          outline: none;
          border-color: #3498db;
        }
        
        .form-textarea {
          resize: vertical;
          min-height: 100px;
        }
        
        .submit-btn {
          background: #3498db;
          color: white;
          border: none;
          padding: 12px 24px;
          border-radius: 6px;
          font-size: 16px;
          font-weight: 600;
          cursor: pointer;
          transition: background-color 0.2s;
        }
        
        .submit-btn:hover:not(:disabled) {
          background: #2980b9;
        }
        
        .submit-btn:disabled {
          background: #bdc3c7;
          cursor: not-allowed;
        }
        
        .error-banner {
          background: #e74c3c;
          color: white;
          padding: 15px;
          border-radius: 6px;
          margin-bottom: 20px;
        }
        
        .loading {
          text-align: center;
          padding: 40px;
          color: #666;
          font-size: 18px;
        }
        
        .results-container {
          background: white;
          border-radius: 8px;
          padding: 30px;
          box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .results-header {
          margin-bottom: 20px;
          padding-bottom: 15px;
          border-bottom: 2px solid #e1e8ed;
        }
        
        .results-title {
          font-size: 1.8rem;
          color: #2c3e50;
          margin-bottom: 10px;
        }
        
        .results-meta {
          color: #666;
          font-size: 14px;
        }
        
        .table-container {
          overflow-x: auto;
        }
        
        .results-table {
          width: 100%;
          border-collapse: collapse;
          margin-top: 20px;
        }
        
        .results-table th,
        .results-table td {
          padding: 12px;
          text-align: left;
          border-bottom: 1px solid #e1e8ed;
        }
        
        .results-table th {
          background: #f8f9fa;
          font-weight: 600;
          color: #2c3e50;
        }
        
        .results-table tr:hover {
          background: #f8f9fa;
        }
        
        .category-positive { color: #27ae60; font-weight: 600; }
        .category-negative { color: #e74c3c; font-weight: 600; }
        .category-edge { color: #f39c12; font-weight: 600; }
        .category-authorization { color: #9b59b6; font-weight: 600; }
        .category-non-functional { color: #34495e; font-weight: 600; }
        
        .test-case-id {
          cursor: pointer;
          color: #3498db;
          font-weight: 600;
          padding: 8px 12px;
          border-radius: 4px;
          transition: background-color 0.2s;
          display: inline-flex;
          align-items: center;
          gap: 8px;
        }
        
        .test-case-id:hover {
          background: #f8f9fa;
        }
        
        .test-case-id.expanded {
          background: #e3f2fd;
          color: #1976d2;
        }
        
        .expand-icon {
          font-size: 10px;
          transition: transform 0.2s;
        }
        
        .expand-icon.expanded {
          transform: rotate(90deg);
        }
        
        .expanded-details {
          margin-top: 15px;
          background: #fafbfc;
          border: 1px solid #e1e8ed;
          border-radius: 8px;
          padding: 20px;
        }
        
        .step-item {
          background: white;
          border: 1px solid #e1e8ed;
          border-radius: 6px;
          padding: 15px;
          margin-bottom: 12px;
          box-shadow: 0 1px 3px rgba(0,0,0,0.05);
        }
        
        .step-header {
          display: grid;
          grid-template-columns: 80px 1fr 1fr 1fr;
          gap: 15px;
          align-items: start;
        }
        
        .step-id {
          font-weight: 600;
          color: #2c3e50;
          background: #f8f9fa;
          padding: 4px 8px;
          border-radius: 4px;
          text-align: center;
          font-size: 12px;
        }
        
        .step-description {
          color: #2c3e50;
          line-height: 1.5;
        }
        
        .step-test-data {
          color: #666;
          font-style: italic;
          font-size: 14px;
        }
        
        .step-expected {
          color: #27ae60;
          font-weight: 500;
          font-size: 14px;
        }
        
        .step-labels {
          display: grid;
          grid-template-columns: 80px 1fr 1fr 1fr;
          gap: 15px;
          margin-bottom: 10px;
          font-weight: 600;
          color: #666;
          font-size: 12px;
          text-transform: uppercase;
          letter-spacing: 0.5px;
        }
      `}</style>
      
      <div className="container">
        <div className="header">
          <h1 className="title">User Story to Tests</h1>
          <p className="subtitle">Generate comprehensive test cases from your user stories</p>
        </div>
        
        <div style={{ marginBottom: 20 }} className="form-container">
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 12 }}>
            <h3 style={{ margin: 0 }}>Jira Integration</h3>
            <div style={{ display: 'flex', gap: 8 }}>
              <button
                type="button"
                className="submit-btn"
                onClick={() => setShowJiraForm(v => !v)}
              >
                {showJiraForm ? 'Hide' : 'Connect Jira'}
              </button>
              {jiraConnected && (
                <button type="button" className="submit-btn" onClick={handleLoadStories}>Refresh Stories</button>
              )}
            </div>
          </div>

          {showJiraForm && (
            <div style={{ marginTop: 12, display: 'grid', gap: 8 }}>
              <input className="form-input" placeholder="Base URL" value={jiraBaseUrl} onChange={e => setJiraBaseUrl(e.target.value)} />
              <input className="form-input" placeholder="Email" value={jiraEmail} onChange={e => setJiraEmail(e.target.value)} />
              <input className="form-input" placeholder="API Token" value={jiraToken} onChange={e => setJiraToken(e.target.value)} />
              <div style={{ display: 'flex', gap: 8 }}>
                <button type="button" className="submit-btn" onClick={handleConnectJira} disabled={jiraLoading}>
                  {jiraLoading ? 'Connecting...' : 'Connect'}
                </button>
                {jiraConnected && (
                  <div style={{ alignSelf: 'center', color: '#27ae60' }}>Connected</div>
                )}
              </div>
              {jiraError && <div className="error-banner">{jiraError}</div>}
            </div>
          )}

          {jiraConnected && jiraProjects.length > 0 && (
            <div style={{ marginTop: 12, display: 'grid', gap: 8 }}>
              <select className="form-input" value={jiraProject} onChange={e => { setJiraProject(e.target.value); handleLoadStoriesForProject(e.target.value) }}>
                <option value="">Select a project...</option>
                {jiraProjects.map(p => (
                  <option key={p.key} value={p.key}>{p.name} ({p.key})</option>
                ))}
              </select>
            </div>
          )}

          {jiraConnected && (
            <div style={{ marginTop: 12, display: 'flex', gap: 8, alignItems: 'center' }}>
              <select className="form-input" value={selectedStory} onChange={e => setSelectedStory(e.target.value)}>
                <option value="">Select a story to link...</option>
                {stories.map(s => (
                  <option key={s.id} value={s.id}>{`${s.id} — ${s.title}`}</option>
                ))}
              </select>
              <button type="button" className="submit-btn" onClick={handleLinkStory} disabled={!selectedStory || jiraLoading}>
                {jiraLoading ? 'Linking...' : 'Link Story'}
              </button>
              <button type="button" className="submit-btn" onClick={handleLoadStories} disabled={jiraLoading}>
                {jiraLoading ? 'Refreshing...' : 'Refresh Stories'}
              </button>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="form-container">
          <div className="form-group">
            <label htmlFor="storyTitle" className="form-label">
              Story Title *
            </label>
            <input
              type="text"
              id="storyTitle"
              className="form-input"
              value={formData.storyTitle}
              onChange={(e) => handleInputChange('storyTitle', e.target.value)}
              placeholder="Enter the user story title..."
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="description" className="form-label">
              Description
            </label>
            <textarea
              id="description"
              className="form-textarea"
              value={formData.description}
              onChange={(e) => handleInputChange('description', e.target.value)}
              placeholder="Additional description (optional)..."
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="acceptanceCriteria" className="form-label">
              Acceptance Criteria *
            </label>
            <textarea
              id="acceptanceCriteria"
              className="form-textarea"
              value={formData.acceptanceCriteria}
              onChange={(e) => handleInputChange('acceptanceCriteria', e.target.value)}
              placeholder="Enter the acceptance criteria..."
              required
            />
          </div>
          
          <div className="form-group">
            <label htmlFor="additionalInfo" className="form-label">
              Additional Info
            </label>
            <textarea
              id="additionalInfo"
              className="form-textarea"
              value={formData.additionalInfo}
              onChange={(e) => handleInputChange('additionalInfo', e.target.value)}
              placeholder="Any additional information (optional)..."
            />
          </div>
          
          <button
            type="submit"
            className="submit-btn"
            disabled={isLoading}
          >
            {isLoading ? 'Generating...' : 'Generate'}
          </button>
        </form>

        <div style={{ marginTop: 12, display: 'flex', gap: 8 }}>
          <button
            className="submit-btn"
            onClick={() => downloadCSV(results?.cases ?? [])}
            disabled={!results || results.cases.length === 0}
          >
            Download CSV
          </button>
          <button
            className="submit-btn"
            onClick={() => downloadXLSX(results?.cases ?? [])}
            disabled={!results || results.cases.length === 0}
          >
            Download XLSX
          </button>
          <button
            className="submit-btn"
            onClick={() => downloadPDF(results?.cases ?? [])}
            disabled={!results || results.cases.length === 0}
          >
            Download PDF
          </button>
        </div>

        {error && (
          <div className="error-banner">
            {error}
          </div>
        )}

        {isLoading && (
          <div className="loading">
            Generating test cases...
          </div>
        )}

        {results && (
          <div className="results-container">
            <div className="results-header">
              <h2 className="results-title">Generated Test Cases</h2>
              <div className="results-meta">
                {results.cases.length} test case(s) generated
                {results.model && ` • Model: ${results.model}`}
                {results.promptTokens > 0 && ` • Tokens: ${results.promptTokens + results.completionTokens}`}
              </div>
              <div style={{ marginTop: 12, display: 'flex', gap: 8 }}>
                <button className="submit-btn" onClick={() => downloadCSV(results.cases)}>Download CSV</button>
                <button className="submit-btn" onClick={() => downloadXLSX(results.cases)}>Download XLSX</button>
                <button className="submit-btn" onClick={() => downloadPDF(results.cases)}>Download PDF</button>
              </div>
            </div>
            
            <div className="table-container">
              <table className="results-table">
                <thead>
                  <tr>
                    <th>Test Case ID</th>
                    <th>Title</th>
                    <th>Category</th>
                    <th>Expected Result</th>
                  </tr>
                </thead>
                <tbody>
                  {results.cases.map((testCase: TestCase) => (
                    <>
                      <tr key={testCase.id}>
                        <td>
                          <div 
                            className={`test-case-id ${expandedTestCases.has(testCase.id) ? 'expanded' : ''}`}
                            onClick={() => toggleTestCaseExpansion(testCase.id)}
                          >
                            <span className={`expand-icon ${expandedTestCases.has(testCase.id) ? 'expanded' : ''}`}>
                              ▶
                            </span>
                            {testCase.id}
                          </div>
                        </td>
                        <td>{testCase.title}</td>
                        <td>
                          <span className={`category-${testCase.category.toLowerCase()}`}>
                            {testCase.category}
                          </span>
                        </td>
                        <td>{testCase.expectedResult}</td>
                      </tr>
                      {expandedTestCases.has(testCase.id) && (
                        <tr key={`${testCase.id}-details`}>
                          <td colSpan={4}>
                            <div className="expanded-details">
                              <h4 style={{marginBottom: '15px', color: '#2c3e50'}}>Test Steps for {testCase.id}</h4>
                              <div className="step-labels">
                                <div>Step ID</div>
                                <div>Step Description</div>
                                <div>Test Data</div>
                                <div>Expected Result</div>
                              </div>
                              {testCase.steps.map((step, index) => (
                                <div key={index} className="step-item">
                                  <div className="step-header">
                                    <div className="step-id">S{String(index + 1).padStart(2, '0')}</div>
                                    <div className="step-description">{step}</div>
                                    <div className="step-test-data">{testCase.testData || 'N/A'}</div>
                                    <div className="step-expected">
                                      {index === testCase.steps.length - 1 ? testCase.expectedResult : 'Step completed successfully'}
                                    </div>
                                  </div>
                                </div>
                              ))}
                            </div>
                          </td>
                        </tr>
                      )}
                    </>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default App